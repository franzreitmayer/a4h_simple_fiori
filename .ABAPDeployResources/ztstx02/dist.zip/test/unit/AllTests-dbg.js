sap.ui.define([
	"eureitmayer.test.apps./ztstx02/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
